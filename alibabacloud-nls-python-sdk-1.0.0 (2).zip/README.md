# alibaba-nls-python-sdk

This is Python SDK for NLS. It supports
SPEECH-RECOGNIZER/SPEECH-SYNTHESIZER/SPEECH-TRANSLATOR/COMMON-REQUESTS-PROTO.

This module works on Python versions:
> 3.6 and greater

install requirements:
> python -m pip install -r requirements.txt

install package:
> python -m pip install .
