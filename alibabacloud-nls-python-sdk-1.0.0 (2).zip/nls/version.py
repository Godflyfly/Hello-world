# Copyright (c) Alibaba, Inc. and its affiliates.
__version__ = '1.0.0'