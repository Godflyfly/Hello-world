import time
import threading
import pyaudio
import sys
import nls

URL = "wss://nls-gateway-cn-shanghai.aliyuncs.com/ws/v1"
TOKEN = "9f067a5fcda14ed68b7807c79774a417"  # 鍙傝€僪ttps://help.aliyun.com/document_detail/450255.html鑾峰彇token
APPKEY = "JNbplHCzbWk4PVCH"  #

# 配置麦克风参数
CHUNK = 640  # 每次读取的音频块大小
FORMAT = pyaudio.paInt16  # 音频格式
CHANNELS = 1  # 声道数
RATE = 16000  # 采样率


class TestSt:
    def __init__(self, tid):
        self.__th = threading.Thread(target=self.__test_run)
        self.__id = tid
        self.__running = False

    def start(self):
        self.__running = True
        self.__th.start()

    def stop(self):
        self.__running = False
        self.__th.join()

    def test_on_sentence_begin(self, message, *args):
        print("test_on_sentence_begin:{}".format(message))

    def test_on_sentence_end(self, message, *args):
        print("test_on_sentence_end:{}".format(message))

    def test_on_start(self, message, *args):
        print("test_on_start:{}".format(message))

    def test_on_error(self, message, *args):
        print("on_error args=>{}".format(args))

    def test_on_close(self, *args):
        print("on_close: args=>{}".format(args))

    def test_on_result_chg(self, message, *args):
        print("test_on_chg:{}".format(message))

    def test_on_completed(self, message, *args):
        print("on_completed:args=>{} message=>{}".format(args, message))

    def __test_run(self):
        print("thread:{} start..".format(self.__id))
        sr = nls.NlsSpeechTranscriber(
            url=URL,
            token=TOKEN,
            appkey=APPKEY,
            on_sentence_begin=self.test_on_sentence_begin,
            on_sentence_end=self.test_on_sentence_end,
            on_start=self.test_on_start,
            on_result_changed=self.test_on_result_chg,
            on_completed=self.test_on_completed,
            on_error=self.test_on_error,
            on_close=self.test_on_close,
            callback_args=[self.__id]
        )

        print("{}: session start".format(self.__id))
        r = sr.start(aformat="pcm",
                     enable_intermediate_result=True,
                     enable_punctuation_prediction=True,
                     enable_inverse_text_normalization=True)

        # 打开麦克风流
        audio = pyaudio.PyAudio()
        stream = audio.open(format=FORMAT, channels=CHANNELS, rate=RATE, input=True, frames_per_buffer=CHUNK)

        while self.__running:
            data = stream.read(CHUNK)
            sr.send_audio(data)
            time.sleep(0.01)

        sr.ctrl(ex={"test": "tttt"})
        time.sleep(1)

        r = sr.stop()
        print("{}: sr stopped:{}".format(self.__id, r))
        time.sleep(1)

        # 关闭麦克风流
        stream.stop_stream()
        stream.close()
        audio.terminate()


def multiruntest(num=1):
    threads = []
    for i in range(0, num):
        name = "thread" + str(i)
        t = TestSt(name)
        threads.append(t)
        t.start()

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        for t in threads:
            t.stop()


nls.enableTrace(False)
multiruntest(1)
