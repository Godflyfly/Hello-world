# Copyright (c) Alibaba, Inc. and its affiliates.

import os

# only for test
TEST_ACCESS_AKID = os.environ['LTAI5tDCzVftnah6wUSotnQA']
TEST_ACCESS_AKKEY = os.environ['9dfDZB8lpV4KYNDZbV0NE1x0K5XCsN']
TEST_ACCESS_TOKEN = os.environ['2f02482df122472f8d890bf895e98025']
TEST_ACCESS_APPKEY = os.environ['JNbplHCzbWk4PVCH']

