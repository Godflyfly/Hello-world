import os
from openai import OpenAI

client = OpenAI(
    api_key = "9ec5a9f8-d11c-4571-8394-bd196b209fe4",
    base_url = "https://ark.cn-beijing.volces.com/api/v3",
)

print("----- streaming request -----")
stream = client.chat.completions.create(
    model = "ep-20240725171057-kfzcp",  # your model endpoint ID
    messages = [
        {"role": "system", "content": "你是豆包，是由字节跳动开发的 AI 人工智能助手"},
        {"role": "user", "content": "讲个非常好笑的段子，别讲有一天螃蟹出门的笑话了"},
    ],
    stream=True
)

for chunk in stream:
    if not chunk.choices:
        continue
    print(chunk.choices[0].delta.content, end="")
print()