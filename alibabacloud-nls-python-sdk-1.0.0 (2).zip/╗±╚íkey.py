import random
import json


def generate_random_keys(n):
    keys = []
    for _ in range(n):
        key = ''.join(random.choices('0123456789abcdefghijklmnokqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!@#$%^&*()', k=10))
        keys.append(key)
    return keys


def add_keys_to_json(filename, keys_durations):
    data = {}
    for key, duration in keys_durations.items():
        expire_at = ""  # 初始化失效时间为空字符串
        data[key] = {
            "duration": duration,
            "expire_at": expire_at
        }

    with open(filename, 'w') as file:  # 使用'w'模式写入内容
        json.dump(data, file, indent=4)

    print(f"JSON文件 '{filename}' 已更新.")


# 定义生成的key的数量和时长
n = 500  # 随机生成500个key
m = 600  # 每个key的时长为600秒

# 随机生成key并添加到字典中
new_keys = generate_random_keys(n)
new_keys_durations = {key: m for key in new_keys}

# 将新生成的key添加到JSON文件中
filename = "keys_durations.json"
add_keys_to_json(filename, new_keys_durations)
